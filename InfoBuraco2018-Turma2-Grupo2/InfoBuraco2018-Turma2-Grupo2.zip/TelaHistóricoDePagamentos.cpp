#include "TelaHist�ricoDePagamentos.h"

