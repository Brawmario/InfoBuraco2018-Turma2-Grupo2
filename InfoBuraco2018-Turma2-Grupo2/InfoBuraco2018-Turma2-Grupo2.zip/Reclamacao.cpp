#include "Reclamacao.h"
//Begin section for file Reclamacao.cpp
//TODO: Add definitions that you want preserved
//End section for file Reclamacao.cpp



//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
Reclamacao::Reclamacao() 
{
    //TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
Reclamacao::~Reclamacao() 
{
    //TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
std::string & Reclamacao::get_contato() 
{
    //TODO Auto-generated method stub
    return contato;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
// Deu ERROOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO ->Date & Reclamacao::get_data() 
// Deu ERROOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO ->{
// Deu ERROOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO ->    //TODO Auto-generated method stub
// Deu ERROOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO ->    return data;
// Deu ERROOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO ->}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
// Deu ERROOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO ->void Reclamacao::set_data(Date & data) 
// Deu ERROOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO ->{
    //TODO Auto-generated method stub
	// Deu ERROOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO ->    this->data = data;
	// Deu ERROOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO ->}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
std::string & Reclamacao::get_hora() 
{
    //TODO Auto-generated method stub
    return hora;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
std::string & Reclamacao::get_identificacao() 
{
    //TODO Auto-generated method stub
    return identificacao;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
std::string & Reclamacao::get_fotografia() 
{
    //TODO Auto-generated method stub
    return fotografia;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
Buraco * & Reclamacao::get_buraco() 
{
    //TODO Auto-generated method stub
    return buraco;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void Reclamacao::set_buraco(Buraco * & buraco) 
{
    //TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
MensagemDeFinaliza��oDeOS * & Reclamacao::get_mensagemDeFinaliza��oDeOS() 
{
    //TODO Auto-generated method stub
    return mensagemDeFinaliza��oDeOS;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void Reclamacao::set_mensagemDeFinaliza��oDeOS(MensagemDeFinaliza��oDeOS * & mensagemDeFinaliza��oDeOS) 
{
    //TODO Auto-generated method stub
}
