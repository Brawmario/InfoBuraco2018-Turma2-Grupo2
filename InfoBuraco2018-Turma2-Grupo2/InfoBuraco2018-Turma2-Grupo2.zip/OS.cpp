#include "OS.h"
//Begin section for file OS.cpp
//TODO: Add definitions that you want preserved
//End section for file OS.cpp



//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
OS::OS()
{
	//TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
OS::~OS()
{
	//TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
int & OS::get_identificacao()
{
	//TODO Auto-generated method stub
	return identificacao;
}
void OS::set_identificacao(int & identificacao)
{
	//TODO Auto-generated method stub
	this->identificacao = identificacao;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
std::string & OS::get_prioridadeAtendimento()
{
	//TODO Auto-generated method stub
	return prioridadeAtendimento;
}
void OS::set_prioridadeAtendimento(std::string & prioridadeAtendimento)
{
	//TODO Auto-generated method stub
	this->prioridadeAtendimento = prioridadeAtendimento;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
int & OS::get_estimativaPessoal()
{
	//TODO Auto-generated method stub
	return estimativaPessoal;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void OS::set_estimativaPessoal(int & estimativaPessoal)
{
	//TODO Auto-generated method stub
	this->estimativaPessoal = estimativaPessoal;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
float & OS::get_estimativaEquipamento()
{
	//TODO Auto-generated method stub
	return estimativaEquipamento;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void OS::set_estimativaEquipamento(float & estimativaEquipamento)
{
	//TODO Auto-generated method stub
	this->estimativaEquipamento = estimativaEquipamento;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
float & OS::get_estimativaMaterial()
{
	//TODO Auto-generated method stub
	return estimativaMaterial;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void OS::set_estimativaMaterial(float & estimativaMaterial)
{
	//TODO Auto-generated method stub
	this->estimativaMaterial = estimativaMaterial;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
float & OS::get_custoEstimado()
{
	//TODO Auto-generated method stub
	return custoEstimado;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void OS::set_custoEstimado(float & custoEstimado)
{
	//TODO Auto-generated method stub
	this->custoEstimado = custoEstimado;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
std::string & OS::get_status()
{
	//TODO Auto-generated method stub
	return status;
}
void OS::set_status(std::string & status)
{
	//TODO Auto-generated method stub
	this->status = status;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
Buraco * & OS::get_buraco()
{
	//TODO Auto-generated method stub
	return buraco;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void OS::set_buraco(Buraco * & buraco)
{
	//TODO Auto-generated method stub
	this->buraco = buraco;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
PlanoSaida * & OS::get_planoSaida()
{
	//TODO Auto-generated method stub
	return planoSaida;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void OS::set_planoSaida(PlanoSaida * & planoSaida)
{
	//TODO Auto-generated method stub
	this->planoSaida = planoSaida;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
RegistroDeComprimentoDeOS * & OS::get_registroDeComprimentoDeOS()
{
	//TODO Auto-generated method stub
	return registroDeComprimentoDeOS;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void OS::set_registroDeComprimentoDeOS(RegistroDeComprimentoDeOS * & registroDeComprimentoDeOS)
{
	//TODO Auto-generated method stub
	this->registroDeComprimentoDeOS = registroDeComprimentoDeOS;
}
