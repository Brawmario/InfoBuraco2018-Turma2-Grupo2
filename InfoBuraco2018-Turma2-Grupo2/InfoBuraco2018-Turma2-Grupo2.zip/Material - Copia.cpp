#include "Material.h"
//Begin section for file Material.cpp
//TODO: Add definitions that you want preserved
//End section for file Material.cpp



//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
Material::Material() 
{
    //TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
Material::~Material() 
{
    //TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
std::string & Material::get_nome() 
{
    //TODO Auto-generated method stub
    return nome;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
float & Material::get_custoUnidade() 
{
    //TODO Auto-generated method stub
    return custoUnidade;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void Material::set_custoUnidade(float & custoUnidade) 
{
    //TODO Auto-generated method stub
    this->custoUnidade = custoUnidade;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
std::string & Material::get_unidade() 
{
    //TODO Auto-generated method stub
    return unidade;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
PlanoSaida * & Material::get_planoSaida() 
{
    //TODO Auto-generated method stub
    return planoSaida;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void Material::set_planoSaida(PlanoSaida * & planoSaida) 
{
    //TODO Auto-generated method stub
}
