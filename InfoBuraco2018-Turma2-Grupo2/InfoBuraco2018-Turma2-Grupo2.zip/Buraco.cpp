#include "Buraco.h"
//Begin section for file Buraco.cpp
//TODO: Add definitions that you want preserved
//End section for file Buraco.cpp



//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
Buraco::Buraco() 
{
    //TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
Buraco::~Buraco() 
{
    //TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
std::string & Buraco::get_identificacao() 
{
    //TODO Auto-generated method stub
    return identificacao;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
std::string & Buraco::get_localizacao() 
{
    //TODO Auto-generated method stub
    return localizacao;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
std::string & Buraco::get_tamanho() 
{
    //TODO Auto-generated method stub
    return tamanho;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
std::string & Buraco::get_posicaoRelativa() 
{
    //TODO Auto-generated method stub
    return posicaoRelativa;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
std::string & Buraco::get_regional() 
{
    //TODO Auto-generated method stub
    return regional;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
int & Buraco::get_numReclamacoes() 
{
    //TODO Auto-generated method stub
    return numReclamacoes;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void Buraco::set_numReclamacoes(int & numReclamacoes) 
{
    //TODO Auto-generated method stub
    this->numReclamacoes = numReclamacoes;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
bool & Buraco::get_buracoReaberto() 
{
    //TODO Auto-generated method stub
    return buracoReaberto;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void Buraco::set_buracoReaberto(bool & buracoReaberto) 
{
    //TODO Auto-generated method stub
    this->buracoReaberto = buracoReaberto;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
Reclamacao * & Buraco::get_reclamacao() 
{
    //TODO Auto-generated method stub
    return reclamacao;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void Buraco::set_reclamacao(Reclamacao * & reclamacao) 
{
    //TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
OS * & Buraco::get_oS() 
{
    //TODO Auto-generated method stub
    return oS;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void Buraco::set_oS(OS * & oS) 
{
    //TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
OS * & Buraco::get_oS2() 
{
    //TODO Auto-generated method stub
    return oS2;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void Buraco::set_oS2(OS * & oS2) 
{
    //TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
OS * & Buraco::get_oS3() 
{
    //TODO Auto-generated method stub
    return oS3;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void Buraco::set_oS3(OS * & oS3) 
{
    //TODO Auto-generated method stub
}
