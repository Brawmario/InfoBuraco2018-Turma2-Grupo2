#include "MensagemDeFinaliza��oDeOS.h"
//Begin section for file MensagemDeFinaliza��oDeOS.cpp
//TODO: Add definitions that you want preserved
//End section for file MensagemDeFinaliza��oDeOS.cpp



//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
MensagemDeFinaliza��oDeOS::MensagemDeFinaliza��oDeOS() 
{
    //TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
MensagemDeFinaliza��oDeOS::~MensagemDeFinaliza��oDeOS() 
{
    //TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
std::string & MensagemDeFinaliza��oDeOS::get_texto() 
{
    //TODO Auto-generated method stub
    return texto;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
std::string & MensagemDeFinaliza��oDeOS::get_destinatario() 
{
    //TODO Auto-generated method stub
    return destinatario;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
Reclamacao * & MensagemDeFinaliza��oDeOS::get_reclamacao() 
{
    //TODO Auto-generated method stub
    return reclamacao;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void MensagemDeFinaliza��oDeOS::set_reclamacao(Reclamacao * & reclamacao) 
{
    //TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
RegistroDeComprimentoDeOS * & MensagemDeFinaliza��oDeOS::get_registroDeComprimentoDeOS() 
{
    //TODO Auto-generated method stub
    return registroDeComprimentoDeOS;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void MensagemDeFinaliza��oDeOS::set_registroDeComprimentoDeOS(RegistroDeComprimentoDeOS * & registroDeComprimentoDeOS) 
{
    //TODO Auto-generated method stub
}
