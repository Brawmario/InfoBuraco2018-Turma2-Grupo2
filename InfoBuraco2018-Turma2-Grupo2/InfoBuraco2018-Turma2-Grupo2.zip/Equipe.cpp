#include "Equipe.h"
//Begin section for file Equipe.cpp
//TODO: Add definitions that you want preserved
//End section for file Equipe.cpp



//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
Equipe::Equipe() 
{
    //TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
Equipe::~Equipe() 
{
    //TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
int & Equipe::get_numeroProfissionais() 
{
    //TODO Auto-generated method stub
    return numeroProfissionais;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void Equipe::set_numeroProfissionais(int & numeroProfissionais) 
{
    //TODO Auto-generated method stub
    this->numeroProfissionais = numeroProfissionais;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
std::string & Equipe::get_nome() 
{
    //TODO Auto-generated method stub
    return nome;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
float & Equipe::get_custoHora() 
{
    //TODO Auto-generated method stub
    return custoHora;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void Equipe::set_custoHora(float & custoHora) 
{
    //TODO Auto-generated method stub
    this->custoHora = custoHora;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
PlanoSaida * & Equipe::get_planoSaida() 
{
    //TODO Auto-generated method stub
    return planoSaida;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void Equipe::set_planoSaida(PlanoSaida * & planoSaida) 
{
    //TODO Auto-generated method stub
}
