#include "Conta.h"
//Begin section for file Conta.cpp
//TODO: Add definitions that you want preserved
//End section for file Conta.cpp


//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
Conta::Conta() 
{
    //TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
Conta::~Conta() 
{
    //TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
int & Conta::get_tipo() 
{
    //TODO Auto-generated method stub
    return tipo;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void Conta::set_tipo(int & tipo) 
{
    //TODO Auto-generated method stub
    this->tipo = tipo;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
std::string & Conta::get_login() 
{
    //TODO Auto-generated method stub
    return login;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
std::string & Conta::get_Senha() 
{
    //TODO Auto-generated method stub
    return Senha;
}
