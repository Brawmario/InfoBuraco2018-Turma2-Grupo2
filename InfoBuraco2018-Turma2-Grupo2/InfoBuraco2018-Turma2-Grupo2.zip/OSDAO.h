#pragma once
#include "dao/MySQLDAO.h"
ref class OSDAO
{
public:
	OSDAO();
	//sql::ResultSet ListarOS();

};

