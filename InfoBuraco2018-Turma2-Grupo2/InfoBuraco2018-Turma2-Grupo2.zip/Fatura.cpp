#include "Fatura.h"
//Begin section for file Fatura.cpp
//TODO: Add definitions that you want preserved
//End section for file Fatura.cpp



//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
Fatura::Fatura() 
{
    //TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
Fatura::~Fatura() 
{
    //TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
float & Fatura::get_valor() 
{
    //TODO Auto-generated method stub
    return valor;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void Fatura::set_valor(float & valor) 
{
    //TODO Auto-generated method stub
    this->valor = valor;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
std::string & Fatura::get_dataEmissao() 
{
    //TODO Auto-generated method stub
    return dataEmissao;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
RegistroDeComprimentoDeOS * & Fatura::get_registroDeComprimentoDeOS() 
{
    //TODO Auto-generated method stub
    return registroDeComprimentoDeOS;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void Fatura::set_registroDeComprimentoDeOS(RegistroDeComprimentoDeOS * & registroDeComprimentoDeOS) 
{
    //TODO Auto-generated method stub
}
