#include "Equipamento.h"
//Begin section for file Equipamento.cpp
//TODO: Add definitions that you want preserved
//End section for file Equipamento.cpp



//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
Equipamento::Equipamento() 
{
    //TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
Equipamento::~Equipamento() 
{
    //TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
std::string & Equipamento::get_identificacao() 
{
    //TODO Auto-generated method stub
    return identificacao;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
float & Equipamento::get_custo() 
{
    //TODO Auto-generated method stub
    return custo;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void Equipamento::set_custo(float & custo) 
{
    //TODO Auto-generated method stub
    this->custo = custo;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
std::string & Equipamento::get_dataFabricacao() 
{
    //TODO Auto-generated method stub
    return dataFabricacao;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
PlanoSaida * & Equipamento::get_planoSaida() 
{
    //TODO Auto-generated method stub
    return planoSaida;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void Equipamento::set_planoSaida(PlanoSaida * & planoSaida) 
{
    //TODO Auto-generated method stub
}
