#include "RegistroDeComprimentoDeOS.h"
//Begin section for file RegistroDeComprimentoDeOS.cpp
//TODO: Add definitions that you want preserved
//End section for file RegistroDeComprimentoDeOS.cpp



//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
RegistroDeComprimentoDeOS::RegistroDeComprimentoDeOS() 
{
    //TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
RegistroDeComprimentoDeOS::~RegistroDeComprimentoDeOS() 
{
    //TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
std::string & RegistroDeComprimentoDeOS::get_data() 
{
    //TODO Auto-generated method stub
    return data;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
std::string & RegistroDeComprimentoDeOS::get_ImagemDoBuracoConsertado() 
{
    //TODO Auto-generated method stub
    return ImagemDoBuracoConsertado;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
std::string & RegistroDeComprimentoDeOS::get_statusAtualizadoDaOS() 
{
    //TODO Auto-generated method stub
    return statusAtualizadoDaOS;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
float & RegistroDeComprimentoDeOS::get_custoDaOperacao() 
{
    //TODO Auto-generated method stub
    return custoDaOperacao;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void RegistroDeComprimentoDeOS::set_custoDaOperacao(float & custoDaOperacao) 
{
    //TODO Auto-generated method stub
    this->custoDaOperacao = custoDaOperacao;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
Relatorio * & RegistroDeComprimentoDeOS::get_relatorio() 
{
    //TODO Auto-generated method stub
    return relatorio;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void RegistroDeComprimentoDeOS::set_relatorio(Relatorio * & relatorio) 
{
    //TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
Fatura * & RegistroDeComprimentoDeOS::get_fatura() 
{
    //TODO Auto-generated method stub
    return fatura;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void RegistroDeComprimentoDeOS::set_fatura(Fatura * & fatura) 
{
    //TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
MensagemDeFinaliza��oDeOS * & RegistroDeComprimentoDeOS::get_mensagemDeFinaliza��oDeOS() 
{
    //TODO Auto-generated method stub
    return mensagemDeFinaliza��oDeOS;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void RegistroDeComprimentoDeOS::set_mensagemDeFinaliza��oDeOS(MensagemDeFinaliza��oDeOS * & mensagemDeFinaliza��oDeOS) 
{
    //TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
OS * & RegistroDeComprimentoDeOS::get_oS() 
{
    //TODO Auto-generated method stub
    return oS;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void RegistroDeComprimentoDeOS::set_oS(OS * & oS) 
{
    //TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
PlanoSaida * & RegistroDeComprimentoDeOS::get_planoSaida() 
{
    //TODO Auto-generated method stub
    return planoSaida;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void RegistroDeComprimentoDeOS::set_planoSaida(PlanoSaida * & planoSaida) 
{
    //TODO Auto-generated method stub
}
