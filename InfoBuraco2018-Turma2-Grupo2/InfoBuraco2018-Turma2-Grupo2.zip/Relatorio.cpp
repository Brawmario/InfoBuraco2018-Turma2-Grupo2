#include "Relatorio.h"
//Begin section for file Relatorio.cpp
//TODO: Add definitions that you want preserved
//End section for file Relatorio.cpp



//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
Relatorio::Relatorio() 
{
    //TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
Relatorio::~Relatorio() 
{
    //TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
std::string & Relatorio::get_tipo() 
{
    //TODO Auto-generated method stub
    return tipo;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
std::string & Relatorio::get_texto() 
{
    //TODO Auto-generated method stub
    return texto;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
RegistroDeComprimentoDeOS * & Relatorio::get_registroDeComprimentoDeOS() 
{
    //TODO Auto-generated method stub
    return registroDeComprimentoDeOS;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void Relatorio::set_registroDeComprimentoDeOS(RegistroDeComprimentoDeOS * & registroDeComprimentoDeOS) 
{
    //TODO Auto-generated method stub
}
