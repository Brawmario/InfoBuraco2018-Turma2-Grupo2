#include "PlanoSaida.h"
//Begin section for file PlanoSaida.cpp
//TODO: Add definitions that you want preserved
//End section for file PlanoSaida.cpp



//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
PlanoSaida::PlanoSaida() 
{
    //TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
PlanoSaida::~PlanoSaida() 
{
    //TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
std::string & PlanoSaida::get_data() 
{
    //TODO Auto-generated method stub
    return data;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
OS * & PlanoSaida::get_oS() 
{
    //TODO Auto-generated method stub
    return oS;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void PlanoSaida::set_oS(OS * & oS) 
{
    //TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
Equipamento * & PlanoSaida::get_equipamento() 
{
    //TODO Auto-generated method stub
    return equipamento;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void PlanoSaida::set_equipamento(Equipamento * & equipamento) 
{
    //TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
Equipe * & PlanoSaida::get_equipe() 
{
    //TODO Auto-generated method stub
    return equipe;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void PlanoSaida::set_equipe(Equipe * & equipe) 
{
    //TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
Material * & PlanoSaida::get_material() 
{
    //TODO Auto-generated method stub
    return material;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void PlanoSaida::set_material(Material * & material) 
{
    //TODO Auto-generated method stub
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
RegistroDeComprimentoDeOS * & PlanoSaida::get_registroDeComprimentoDeOS() 
{
    //TODO Auto-generated method stub
    return registroDeComprimentoDeOS;
}
//@generated "UML to C++ (com.ibm.xtools.transform.uml2.cpp.CPPTransformation)"
void PlanoSaida::set_registroDeComprimentoDeOS(RegistroDeComprimentoDeOS * & registroDeComprimentoDeOS) 
{
    //TODO Auto-generated method stub
}
